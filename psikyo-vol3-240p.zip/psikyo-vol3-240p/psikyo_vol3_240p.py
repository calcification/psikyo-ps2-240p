#!/usr/bin/env python3
"""
psikyo_vol3_240p.py -- native 240p patch for Psikyo Shooting Collection Vol. 3 (PS2, SLPM-62593).

Usage:
    python3 psikyo_vol3_240p.py down2 <original.iso> <output.iso>

Variants:
    down2    The patch. Two-pass 2:1 bilinear downscale of the game's 640x448 frame into a
             640x224 image, shown in progressive (240p) video. Verified in PCSX2 and on real
             PS2 hardware (composite, CRT) with Dragon Blaze.
    bands    Diagnostic only: four solid colour bands in place of the picture.
    inplace  Diagnostic only: single-pass in-place downscale (reads and writes overlapping
             VRAM in one primitive; not safe to rely on).

The script only reads <original.iso>; it writes a new file. Every patch site and the code cave
are verified against expected original bytes (and a SHA-1 for the cave) before anything is
written, so it aborts on a wrong or already-patched image.
See README.md and docs/ for how it works.
"""
import sys, struct, shutil, hashlib
MAIN = lambda rt: 0x9679900 + (rt - 0x100000)
CAVE_START, CAVE_END = 0x145ba8, 0x1460b8
CODE1, PKT = 0x145bb0, 0x145d00
EXPECT_SHA1 = "07790bc5113becffd1b1dbbd6d281310f038aae8"
Rn = {n:i for i,n in enumerate("zero at v0 v1 a0 a1 a2 a3 t0 t1 t2 t3 t4 t5 t6 t7 s0 s1 s2 s3 s4 s5 s6 s7 t8 t9 k0 k1 gp sp fp ra".split())}
def I(op,rs,rt,i): return (op<<26)|(Rn[rs]<<21)|(Rn[rt]<<16)|(i&0xffff)
addiu=lambda rt,rs,i:I(9,rs,rt,i); andi=lambda rt,rs,i:I(0xc,rs,rt,i); ori=lambda rt,rs,i:I(0xd,rs,rt,i)
lui=lambda rt,i:I(0xf,'zero',rt,i); lw=lambda rt,o,rs:I(0x23,rs,rt,o); sw=lambda rt,o,rs:I(0x2b,rs,rt,o)
ld=lambda rt,o,rs:I(0x37,rs,rt,o); sd=lambda rt,o,rs:I(0x3f,rs,rt,o)
sll=lambda rd,rt,sh:(Rn[rt]<<16)|(Rn[rd]<<11)|(sh<<6)
orr=lambda rd,rs,rt:(Rn[rs]<<21)|(Rn[rt]<<16)|(Rn[rd]<<11)|0x25
subu=lambda rd,rs,rt:(Rn[rs]<<21)|(Rn[rt]<<16)|(Rn[rd]<<11)|0x23
jal=lambda t:(3<<26)|((t>>2)&0x3ffffff); j=lambda t:(2<<26)|((t>>2)&0x3ffffff)
NOP=0
def assemble(base, items):
    pc=base; labels={}
    for it in items:
        if isinstance(it,tuple) and it[0]=='label': labels[it[1]]=pc
        else: pc+=4
    out=[]; pc=base
    for it in items:
        if isinstance(it,tuple) and it[0]=='label': continue
        if isinstance(it,tuple):
            op={'bne':5,'beq':4}[it[0]]; it=I(op,it[1],it[2],(labels[it[3]]-(pc+4))>>2)
        out.append(it); pc+=4
    return b''.join(struct.pack('<I',w) for w in out)

# ---- packet builder: entries are (lo, regaddr); runtime patches recorded as (entry_index, kind)
FRAME_HI = 0x010A0000                         # FBW=10, PSM=CT24 (FBP OR'd in at runtime)
TEX0_LO  = (10<<14)|(1<<20)|(10<<26)|((9&3)<<30)   # TBW10 CT24 TW=1024 TH low bits (TBP0 OR'd in)
TEX0_FULL= TEX0_LO | ((9>>2)<<32) | (1<<35)   # TH high bits, TFX=1 (DECAL)
WHITE    = 0xFF|(0xFF<<8)|(0xFF<<16)|(0x80<<24)|(0x3f800000<<32)
PRIM_TEX = 6|(1<<4)|(1<<8)                    # sprite, TME, FST
def build_packet(variant):
    E=[]; P=[]                                # E entries, P patches
    def add(lo,reg,patch=None):
        E.append((lo,reg))
        if patch: P.append((len(E), patch))   # entry offset = 0x10*len(E)
    scis=(639<<16)|(223<<48)
    if variant=='bands':
        add(FRAME_HI,0x4c,'frameX'); add(1<<32,0x4e); add(0x6C00|(0x7900<<32),0x18); add(scis,0x40); add(0x30000,0x47)
        add(6,0x00)
        for k,c in enumerate([0x800000FF,0x8000FF00,0x80FF0000,0x80FFFFFF]):
            y0=0x7900+k*56*16; y1=y0+56*16
            add(c|(0x3f800000<<32),0x01); add(0x6C00|(y0<<16),0x05); add((0x6C00+640*16)|(y1<<16),0x05)
    else:
        dst_patch='frameY70' if variant=='down2' else 'frameX'
        add(FRAME_HI,0x4c,dst_patch); add(1<<32,0x4e); add(0x6C00|(0x7900<<32),0x18); add(scis,0x40); add(0x30000,0x47)
        add(TEX0_FULL,0x06,'tex0X'); add((1<<5)|(1<<6),0x14); add(0,0x3f)
        add(WHITE,0x01); add(PRIM_TEX,0x00)
        add(0,0x03); add(0x6C00|(0x7900<<16),0x05)
        add(640*16|((448*16)<<16),0x03); add((0x6C00+640*16)|((0x7900+224*16)<<16),0x05)
        if variant=='down2':
            add(FRAME_HI,0x4c,'frameX'); add(TEX0_FULL,0x06,'tex0Y70'); add(0,0x14); add(0,0x3f)   # pass 2: nearest copy
            add(0,0x03); add(0x6C00|(0x7900<<16),0x05)
            add(640*16|((224*16)<<16),0x03); add((0x6C00+640*16)|((0x7900+224*16)<<16),0x05)
    add(0,0x61)                               # FINISH
    pkt=struct.pack('<QQ',len(E)|0x8000|(1<<60),0xE)+b''.join(struct.pack('<QQ',lo,r) for lo,r in E)
    return pkt,P

def build(variant):
    pkt,P=build_packet(variant); plen=len(pkt)
    assert PKT+plen <= CAVE_END
    body=[addiu('sp','sp',-0x20), sd('ra',0,'sp'), sd('a0',8,'sp'),
          ('beq','a0','zero','DONE'), NOP,
          lui('t0',0x17), lw('t0',0x4854,'t0'), addiu('t1','zero',448), ('bne','t0','t1','DONE'), NOP,
          lw('t3',0x10,'a0'), andi('t3','t3',0x1ff),                  # X  = FBP of the composed buffer
          addiu('t6','zero',210), subu('t6','t6','t3'),               # Y70 = (140-X)+70 : scratch in the other buffer's lower half
          lui('t2',PKT>>16), ori('t2','t2',PKT&0xffff)]
    for idx,kind in P:
        off=0x10*idx
        if kind in ('frameX','frameY70'):
            r='t3' if kind=='frameX' else 't6'
            body += [lui('t5',FRAME_HI>>16), orr('t5','t5',r), sw('t5',off,'t2')]
        else:
            r='t3' if kind=='tex0X' else 't6'
            body += [sll('t4',r,5), lui('t5',TEX0_FULL&0xffff0000>>16 if False else (TEX0_FULL&0xffffffff)>>16),
                     ori('t5','t5',TEX0_FULL&0xffff), orr('t5','t5','t4'), sw('t5',off,'t2')]
    body += [lui('t7',0xD), ori('t7','t7',0xF9FF), sw('t7',0x1c,'a0'),   # DISPLAY.DH = 223
             lui('t8',0x1200), ori('t8','t8',0x1000), addiu('t9','zero',2), sd('t9',0,'t8'),   # CSR.FINISH clear
             orr('a0','t2','zero'), jal(0x10e798), addiu('a1','t2',plen-1),                    # D-cache writeback
             lui('a0',PKT>>16), jal(0x100e68), ori('a0','a0',PKT&0xffff),                      # send via game's sender
             lui('t0',4), lui('t8',0x1200), ori('t8','t8',0x1000),
             ('label','W'), ld('t1',0,'t8'), andi('t1','t1',2), ('bne','t1','zero','DONE'),
             addiu('t0','t0',-1), ('bne','t0','zero','W'), NOP,                                # bounded wait for FINISH
             ('label','DONE'), ld('ra',0,'sp'), ld('a0',8,'sp'), j(0x1009f0), addiu('sp','sp',0x20)]
    code=assemble(CODE1,body); assert CODE1+len(code) <= PKT, len(code)
    sites=[(None,0x096BB9E0,'01','00','mode4 a1 1->0'),
           (0x1420d0,None,'01000524','2d280000','mode1 a1 -> 0'),
           (0x1423d0,None,'7c02040c',struct.pack('<I',jal(CODE1)).hex(),'hook PutDispEnv #1'),
           (0x1423e0,None,'7c02040c',struct.pack('<I',jal(CODE1)).hex(),'hook PutDispEnv #2')]
    return sites,[(code,CODE1),(pkt,PKT)]

def main():
    if len(sys.argv)!=4 or sys.argv[1] not in ('bands','down2','inplace'): sys.exit(__doc__)
    variant,src,dst=sys.argv[1:]; sites,blobs=build(variant)
    with open(src,'rb') as f:
        for rt,off,old,new,nm in sites:
            o=off if off is not None else MAIN(rt); f.seek(o); g=f.read(len(old)//2).hex()
            if g!=old: sys.exit(f"ABORT {nm}: expected {old} at {o:#x}, found {g}")
        f.seek(MAIN(CAVE_START)); sha=hashlib.sha1(f.read(CAVE_END-CAVE_START)).hexdigest()
        if sha!=EXPECT_SHA1: sys.exit("ABORT: cave SHA-1 mismatch")
    shutil.copyfile(src,dst)
    with open(dst,'r+b') as f:
        for blob,rt in blobs: f.seek(MAIN(rt)); f.write(blob)
        for rt,off,old,new,nm in sites:
            o=off if off is not None else MAIN(rt); f.seek(o); f.write(bytes.fromhex(new)); print(f"ok {o:#011x} {nm}")
    print("variant",variant,"->",dst)
if __name__=="__main__": main()
