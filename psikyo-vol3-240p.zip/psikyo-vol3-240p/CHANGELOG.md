# Changelog

## 1.0.0 — 2026-11-16
- First working release: `down2` two-pass 2:1 downscale, native 240p.
- Verified: PCSX2 and real PS2 (composite, Sony KV-6PR1 Trinitron, TATE) with Dragon Blaze.
- Code cave moved to the unreferenced function at 0x145ba8–0x1460b8 (SHA-1 checked before writing).
- Added `tools/verify_patch.py` and full documentation.

### Development history (summary)
- M1 / B1–B11: GS injection experiments; found that FBP 280 is the game's offscreen playfield target.
- C1: in-place downscale (rejected: overlapping read/write of VRAM in a single primitive).
- C2: hazard-free two-pass design with GS FINISH wait — this release.
