# Patch specification (`down2`)

Target: NTSC-J **SLPM-62593** disc image. ISO offset = `0x09679900 + (runtime − 0x00100000)` for the main executable.

All locations are verified against the expected original bytes before writing; the script aborts otherwise.

## 1. Patch sites

| ISO offset | Runtime | Original | New | Purpose |
|---|---|---|---|---|
| `0x0096bb9e0` | `0x1420E0` | `01` | `00` | Mode 4 (NTSC field) interlace argument 1→0 (progressive). One byte: `addiu a1,zero,1` → `addiu a1,zero,0` (immediate byte) |
| `0x0096bb9d0` | `0x1420d0` | `01000524` | `2d280000` | Mode 1: `addiu a1,zero,1` → `move a1,zero` (mode 1 now identical to mode 0) |
| `0x0096bbcd0` | `0x1423d0` | `7c02040c` | `ec16050c` | `jal 0x1009F0` → `jal 0x145BB0` (delay slot `addu a0,a0,v1` unchanged) |
| `0x0096bbce0` | `0x1423e0` | `7c02040c` | `ec16050c` | `jal 0x1009F0` → `jal 0x145BB0` (delay slot `addiu a0,s0,0x10` unchanged) |

## 2. Code cave

- Region: runtime `0x145ba8`–`0x1460b8` (1296 bytes), ISO `0x0096bf4a8`–`0x0096bf9b8`.
- This is an unreferenced function: no call, jump, pointer or `lui`/`addiu` address construction in the main executable or either game module refers into it. The script verifies SHA-1 `07790bc5113becffd1b1dbbd6d281310f038aae8` of the original contents before writing.
- Code: runtime `0x145bb0`, ISO `0x0096bf4b0`, 232 bytes. Packet: runtime `0x145d00`, ISO `0x0096bf600`, 384 bytes (ends `0x145e80`, inside the cave).
- Layout: code occupies `0x145bb0`–`0x145c98`; the packet starts at `0x145d00` (kept aligned); the rest of the cave is untouched.

### Cave code (R5900 / MIPS, little-endian)
```
145bb0: 27bdffe0  addiu $sp,$sp,-32
145bb4: ffbf0000  sd $ra,0x0($sp)
145bb8: ffa40008  sd $a0,0x8($sp)
145bbc: 10800032  beq $a0,$zero,0x145c88
145bc0: 00000000  nop
145bc4: 3c080017  lui $t0,0x17
145bc8: 8d084854  lw $t0,0x4854($t0)
145bcc: 240901c0  addiu $t1,$zero,448
145bd0: 1509002d  bne $t0,$t1,0x145c88
145bd4: 00000000  nop
145bd8: 8c8b0010  lw $t3,0x10($a0)
145bdc: 316b01ff  andi $t3,$t3,0x1ff
145be0: 240e00d2  addiu $t6,$zero,210
145be4: 01cb7023  subu $t6,$t6,$t3
145be8: 3c0a0014  lui $t2,0x14
145bec: 354a5d00  ori $t2,$t2,0x5d00
145bf0: 3c0d010a  lui $t5,0x10a
145bf4: 01ae6825  or $t5,$t5,$t6
145bf8: ad4d0010  sw $t5,0x10($t2)
145bfc: 000b6140  sll $t4,$t3,5
145c00: 3c0d6812  lui $t5,0x6812
145c04: 35ad8000  ori $t5,$t5,0x8000
145c08: 01ac6825  or $t5,$t5,$t4
145c0c: ad4d0060  sw $t5,0x60($t2)
145c10: 3c0d010a  lui $t5,0x10a
145c14: 01ab6825  or $t5,$t5,$t3
145c18: ad4d00f0  sw $t5,0xf0($t2)
145c1c: 000e6140  sll $t4,$t6,5
145c20: 3c0d6812  lui $t5,0x6812
145c24: 35ad8000  ori $t5,$t5,0x8000
145c28: 01ac6825  or $t5,$t5,$t4
145c2c: ad4d0100  sw $t5,0x100($t2)
145c30: 3c0f000d  lui $t7,0xd
145c34: 35eff9ff  ori $t7,$t7,0xf9ff
145c38: ac8f001c  sw $t7,0x1c($a0)
145c3c: 3c181200  lui $t8,0x1200
145c40: 37181000  ori $t8,$t8,0x1000
145c44: 24190002  addiu $t9,$zero,2
145c48: ff190000  sd $t9,0x0($t8)
145c4c: 01402025  or $a0,$t2,$zero
145c50: 0c0439e6  jal 0x10e798
145c54: 2545017f  addiu $a1,$t2,383
145c58: 3c040014  lui $a0,0x14
145c5c: 0c04039a  jal 0x100e68
145c60: 34845d00  ori $a0,$a0,0x5d00
145c64: 3c080004  lui $t0,0x4
145c68: 3c181200  lui $t8,0x1200
145c6c: 37181000  ori $t8,$t8,0x1000
145c70: df090000  ld $t1,0x0($t8)
145c74: 31290002  andi $t1,$t1,0x2
145c78: 15200003  bne $t1,$zero,0x145c88
145c7c: 2508ffff  addiu $t0,$t0,-1
145c80: 1500fffb  bne $t0,$zero,0x145c70
145c84: 00000000  nop
145c88: dfbf0000  ld $ra,0x0($sp)
145c8c: dfa40008  ld $a0,0x8($sp)
145c90: 0804027c  j 0x1009f0
145c94: 27bd0020  addiu $sp,$sp,32
```

Register use: `t3` = X (composed buffer FBP), `t6` = scratch FBP (`210 − X`), `t2` = packet address, `t4`/`t5` = temporaries, `t8`/`t9` = CSR, `t0`/`t1` = wait loop. `ra` and `a0` are saved on the stack and restored before tail-calling `PutDispEnv`.

## 3. Runtime packet patches (done by the cave each frame)

| Packet offset | Register | Value written (low 32 bits) |
|---|---|---|
| `+0x010` | FRAME_1 (pass 1) | `0x010A0000 \| (210 − X)` |
| `+0x060` | TEX0_1 (pass 1) | `0x68128000 \| (X × 32)` |
| `+0x0F0` | FRAME_1 (pass 2) | `0x010A0000 \| X` |
| `+0x100` | TEX0_1 (pass 2) | `0x68128000 \| ((210 − X) × 32)` |

`0x010A0000` = FBW 10, PSM CT24. `0x68128000` = TBW 10, PSM CT24, TW 10 (1024), TH low bits; the high word (`0x0000000A`) adds TH = 9 (512) and TFX = DECAL.

Other cave actions: `DISPLAY` high word at `a0+0x1C` ← `0x000DF9FF` (DH = 223, DW = 2559); `CSR` (`0x12001000`) ← `2` (clear FINISH); then poll CSR bit 1 up to `0x40000` iterations.

## 4. GS packet layout (static part)

GIF tag: `NLOOP=23, EOP=1, FLG=PACKED, NREG=1, REGS=A+D`. Each entry is `low64 high64(register address)`.

| Offset | Register | Low 64 bits | Note |
|---|---|---|---|
| `+0x000` | GIF tag | `1000000000008017` | 23 A+D quadwords |
| `+0x010` | FRAME_1 | `00000000010a0000` | **pass 1** dest FBP patched at runtime |
| `+0x020` | ZBUF_1 | `0000000100000000` | Z writes masked |
| `+0x030` | XYOFFSET_1 | `0000790000006c00` | centre of 640×224 |
| `+0x040` | SCISSOR_1 | `00df0000027f0000` | 640×224 |
| `+0x050` | TEST_1 | `0000000000030000` | ZTE on, ZTST=ALWAYS |
| `+0x060` | TEX0_1 | `0000000a68128000` | source = buffer X; FBP patched at runtime |
| `+0x070` | TEX1_1 | `0000000000000060` | MMAG = MMIN = linear |
| `+0x080` | TEXFLUSH | `0000000000000000` |  |
| `+0x090` | RGBAQ | `3f80000080ffffff` | neutral white |
| `+0x0a0` | PRIM | `0000000000000116` | sprite, TME, FST |
| `+0x0b0` | UV | `0000000000000000` | (0,0) |
| `+0x0c0` | XYZ2 | `0000000079006c00` | (0,0) |
| `+0x0d0` | UV | `000000001c002800` | (640,448) |
| `+0x0e0` | XYZ2 | `0000000087009400` | (640,224) → pass 1 draws 640×224 |
| `+0x0f0` | FRAME_1 | `00000000010a0000` | **pass 2** dest = X; FBP patched |
| `+0x100` | TEX0_1 | `0000000a68128000` | source = scratch; patched |
| `+0x110` | TEX1_1 | `0000000000000000` | nearest |
| `+0x120` | TEXFLUSH | `0000000000000000` |  |
| `+0x130` | UV | `0000000000000000` | (0,0) |
| `+0x140` | XYZ2 | `0000000079006c00` | (0,0) |
| `+0x150` | UV | `000000000e002800` | (640,224) |
| `+0x160` | XYZ2 | `0000000087009400` | (640,224) → pass 2 draws 640×224 |
| `+0x170` | FINISH | `0000000000000000` | raises CSR.FINISH |

(UV/XYZ2 values: 12.4 fixed point. XYOFFSET `OFX=0x6C00`, `OFY=0x7900`, i.e. centre of a 640×224 area.)

## 5. Memory map used

| FBP | Role in the patch |
|---|---|
| X ∈ {0, 140} | source buffer (finished 640×448 frame) and final destination (top 224 rows) |
| (140 − X) + 70 = 210 − X | scratch (rows 224–447 of the other buffer; never displayed) |

## 6. Reverting

The patch is applied to a *copy*. Keep your original ISO; there is nothing to undo.
