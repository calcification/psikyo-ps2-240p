# Testing status and how to help

## Verified

| Configuration | Result |
|---|---|
| Dragon Blaze gameplay, **PCSX2** | PASS — complete image, correct proportions, no cropping, no flicker, no corruption |
| Dragon Blaze gameplay, **real PS2**, composite → Sony KV-6PR1 Trinitron (rotated for TATE) | PASS — complete image, correct proportions, stable, no apparent corruption, no noticeable softness |

Note: the CRT emits an audible buzz in this mode. The same set buzzes the same way with *Ico*, so it appears
to be normal for that display. Exact signal timing has not been independently measured.

## Not yet verified

- Sol Divide gameplay (uses the same 448-row path; expected to work)
- Collection menus, transitions, fades, game-select and options screens
- Pause, continue/game-over, high-score and demo screens
- Other video connections (S-Video, RGB, component) and other PS2 models
- Other displays: scalers, LCD TVs, capture devices
- PAL consoles (the PAL mode entries are deliberately not modified)
- Long-session stability and any performance effect of the per-frame FINISH wait

## Test checklist

1. Patch with `down2`, run `tools/verify_patch.py`, boot.
2. Splash → title → menu → each game → gameplay → pause → continue/game over → return to menu.
3. Watch for: flicker between two images, half-height or stretched pictures, scrambled tiles, brief flashes at
   scene changes, black screens, stutter.
4. Note whether a problem appears on **every** frame or only at a transition.

## Reporting a problem

Please include: emulator or hardware model and video cable, the exact screen/game, whether it is every frame
or only at a transition, and the SHA-256 of your original and patched images (`tools/verify_patch.py` prints
both). A GS dump from PCSX2 taken while the problem is visible is the most useful artifact.

## Known assumptions worth validating (possible hardening)

- **Scratch location.** The scratch FBP is `210 − X`, which is only valid if X (the composed buffer) is 0 or
  140. That holds for every 448-row screen found. A small guard that skips the downscale when X is anything
  else would remove the assumption; it would be a separate, clearly named variant so the verified `down2`
  stays unchanged.
- **Other direct video-mode paths.** Two places in the executable call the reset routine themselves
  (`0x12F24C`, `0x1479B8`) with interlaced NTSC and 224-row buffers. They are not modified.
- **FINISH wait.** It is bounded (about 262,000 polls), so the worst case is a short per-frame stall, not a hang.

## For contributors

- Keep `down2` byte-for-byte stable; propose changes as new named variants.
- Anything new should be a single-variable change with a stated prediction ("if this works we will see X; if
  not, Y"), and should be tested in PCSX2 before real hardware.
