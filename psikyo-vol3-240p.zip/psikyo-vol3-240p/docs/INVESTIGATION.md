# Investigation history

A condensed record of what was tried, so nobody repeats the dead ends.

## Video-mode experiments (original ISO)
Changing interlace, field/frame, or both only ever produced the **upper half** of the image. Conclusion: the
frame is 448 rows tall and must actually be shrunk.

## Things ruled out
- **Vertex-halving in the sprite emitter (`0x131770`)** — that routine draws the *offscreen* playfield sprites,
  not the final screen. Halving there produced no improvement. (Many emitters exist: fixed-point and float,
  258 callers of the rectangle emitter alone.)
- **Doubling DISPFB.FBW** — skips 32-row page bands, not rows.
- **MAGV** — can only magnify.
- **Progressive with FFMD=0** — no effect.
- **Display output at FBP 280** — that is the game's offscreen playfield target, rewritten every frame.

## Milestones
| Step | What it showed |
|---|---|
| M1 (red square) | A custom GS packet can be sent from a cave hooked into the swap; it appears in gameplay. |
| B1 `bands` | The display path (DH = 223, progressive) is correct. Flicker came from the game's compose into FBP 140 overwriting a destination at FBP 210. |
| B2–B11 | Destinations at FBP 280 conflict with the offscreen target: compressed left in PCSX2, scrambled tiles on a real CRT (FBW 8 data read with FBW 10). Markers vanished in gameplay but appeared during fades, when the offscreen pass does not run. |
| B4 | A null-pointer guard on `a0` made diagnostic bands stable. |
| C1 | In-place downscale; rejected because of same-VRAM read/write hazard. |
| **C2 `down2`** | Two-pass via scratch + FINISH wait. **Works in PCSX2 and on real hardware.** |

## Facts established along the way
- Dumps show the swap writes the display env, then kicks the env packet; compose packets follow; the display is
  always the buffer composed the previous frame.
- Context FBP halfwords (`+0xE0`, `+0xE2`) come from draw env 0 (`db+0x60`) and draw env 1 (`db+0x150`).
- `PutDispEnv`'s argument is `0x176600 + (idx&1)*0x28`, or `0x176600` on the other branch; it should never be
  null in steady state. The guard exists as a safeguard because a null `a0` was captured once during
  development and the cause was never fully explained.
- The first cave (unreferenced function at `0x1029D8`) is too small for the two-pass packet; the final patch
  uses `0x145BA8–0x1460B8`, which nothing in the executable or either game module references.

## Honest unknowns
- Why the earlier compose-forcing experiment (`fbands`) behaved as it did was never explained; the final design
  does not use compose forcing.
- Behaviour on other screens and games is untested (see [TESTING.md](TESTING.md)).
