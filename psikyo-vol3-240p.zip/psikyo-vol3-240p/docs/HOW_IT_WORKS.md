# How the 240p patch works

Evidence levels used below: **[verified]** = checked directly against the ISO bytes, GS dumps, or a test
result; **[inferred]** = reasoned from verified facts but not independently proven.

## 1. The problem

The original game outputs 480i and looks correct. The obvious approach — ask the console for 240p — fails:

| Experiment (all on the original ISO) | Result |
|---|---|
| Change only interlace 1→0 | 240p, **upper half** of the image, stretched [verified] |
| Change only field/frame 0→1 | still 480i, **upper half**, stretched [verified] |
| Progressive with FFMD=0 written to SMODE2 | still upper half [verified] |

Both independent changes give the same crop, which points at how the frame is *read out*, not at the video
signal.

### Field vs. frame readout [inferred, consistent with every result]

The game renders a full **640×448** frame. In interlaced **field** mode the GS reads alternate rows of that
buffer for each field, so the whole picture appears. In **frame** or **progressive** mode the GS reads
consecutive rows, so only rows 0–223 are shown, stretched to fill the screen.

No display-register setting produces "progressive, but every other row". Two readout tricks were ruled out:
doubling DISPFB.FBW skips whole 32-row page bands, not single rows; MAGV can only magnify. So the *image
itself* has to become 224 rows tall.

## 2. How the game builds a frame [verified from GS dumps and the executable]

The graphics code is the standard SDK libgraph pattern (`sceGsResetGraph`, `SetDefDBuff`,
`PutDispEnv`, ...). Mode table entries pass `(interlace, NTSC/PAL, field/frame)`:

| Mode | interlace | video | field/frame |
|---|---|---|---|
| 0 | 0 | NTSC | frame |
| 1 | 1 | NTSC | frame |
| 4 | 1 | NTSC | **field** (menus, Dragon Blaze, Sol Divide use this with a 640×448 buffer) |

Per frame:

1. The swap routine writes the display environment (`PutDispEnv`) and then sends a 160-byte "env" packet that
   sets the compose target for the next frame (FRAME, ZBUF, TEX1, CLAMP, TEST, ALPHA, XYOFFSET, SCISSOR, FBA).
2. The playfield is drawn natively into an **offscreen 512×256 target at FBP 280** (about 280 small sprites).
3. The final 640×448 image is composed in the main buffer: a rotated textured blit of the offscreen playfield
   plus two 140-pixel side panels.
4. Vsync. The two main buffers alternate between **FBP 0 and FBP 140**; the display always shows the one
   composed last frame.

Observed VRAM use during Dragon Blaze gameplay (FBP = 8 KB pages):

| FBP | Contents |
|---|---|
| 0–139 | main buffer A (640×448, CT24, FBW 10) |
| 140–279 | main buffer B |
| 280–343 | offscreen playfield target (512×256, FBW 8) — **rewritten every frame** |
| 344–375 | Z16S area for that pass |
| 376–511 | textures (including a 256 KB image uploaded every frame) |

There is no free VRAM for a separate 640×224 output buffer. (Several early attempts placed their output at
FBP 280 and failed for exactly this reason.)

## 3. The solution

### 3.1 Video mode
The mode-4 entry's interlace argument changes 1→0 and the mode-1 entry is made identical to mode 0. Output is
now non-interlaced NTSC (240p) everywhere except the Taito splash.

### 3.2 A hook at the end of each frame
Both calls to `PutDispEnv` (`0x1423D0`, `0x1423E0`) are redirected to a small routine in an unused code cave.
It receives the display environment pointer in `a0` and tail-calls the original `PutDispEnv` when done, so the
game's own flow is preserved.

### 3.3 What the routine does each frame

```
guard:   a0 == 0 ?                       -> skip
gate:    init height at 0x174854 != 448 ? -> skip     (only 448-row screens are processed)
X  = disp.DISPFB.FBP                       the buffer holding the frame that was just composed
Y70 = 210 - X                              scratch: lower half of the OTHER buffer (70 pages)
patch the packet:  pass-1 FRAME=Y70, pass-1 TEX0.TBP0=X*32,
                   pass-2 FRAME=X,   pass-2 TEX0.TBP0=Y70*32
disp.DISPLAY.DH = 223                      show 224 lines
clear CSR.FINISH; write back D-cache; send packet with the game's own GIF-DMA sender (0x100E68)
poll CSR.FINISH (bounded)                  GS done before the display switches
tail-call real PutDispEnv
```

### 3.4 The GS packet (all A+D, 23 registers)

- **Pass 1 (downscale):** read the 640×448 source (texture = buffer X, CT24, TBW 10, 1024×512, DECAL, bilinear)
  and draw a 640×224 sprite into the scratch area `Y70`. Destination row *y* samples V = 2y+1, which lies
  exactly between source rows 2y and 2y+1, so bilinear filtering gives a clean 2:1 box average (U maps 1:1).
- **Pass 2 (copy back):** read the 640×224 scratch (nearest) and draw it 1:1 into rows 0–223 of X.
- Finish with a GS FINISH event.

Because the display switches to buffer X with `DH = 223`, you see the 224 rows of the downscaled image.

### 3.5 Why two passes through a scratch area
A single pass that reads rows of X while writing other rows of X makes the GS read and write overlapping VRAM
inside one primitive. Neither TEXFLUSH nor a top-to-bottom ordering argument guarantees that is safe on real
hardware. Using the other buffer's lower half as scratch makes the read and write sets disjoint in every
primitive.

### 3.6 Why the scratch area is safe [verified for the tested path]
The other buffer is the next compose target and is rewritten from scratch (the env packet and a full clear)
before it is shown, and DH = 223 means rows 224–447 are never scanned out. The routine finishes (FINISH) before
the next frame's packets, so nothing it writes survives into game rendering. `210 − X` is only meaningful when
X is 0 or 140, which holds for every 448-row screen found. A guard for any other X is listed as a possible
hardening step in [TESTING.md](TESTING.md).

### 3.7 State left behind [verified in the dump]
The routine changes FRAME, ZBUF, XYOFFSET, SCISSOR, TEST, TEX0, TEX1, CLAMP (pass-1 only), PRIM and RGBAQ.
The very next packet the game sends is the env packet, which rewrites FRAME, ZBUF, TEX1, CLAMP, TEST, ALPHA,
XYOFFSET, SCISSOR and FBA. TEX0 and PRIM are set by the game before each textured/untextured draw, so nothing
leaks into game rendering.

## 4. Key addresses (main executable, runtime base `0x00100000`)

`ISO offset = 0x09679900 + (runtime address − 0x00100000)`

| Address | Meaning |
|---|---|
| `0x1003C0` | `sceGsResetGraph(mode, inter, omode, ffmode)` |
| `0x100678` | `sceGsSetDefDispEnv` (SMODE2 = 1 field / 3 frame / 2 progressive; DH = h−1 or 2h−1) |
| `0x100B78` | `sceGsSetDefDrawEnv` (ignores field/frame) |
| `0x100F50` | `sceGsSetDefDBuff` |
| `0x1009F0` | `sceGsPutDispEnv` (writes PMODE, SMODE2, DISPFB2, DISPLAY2, BGCOLOR) |
| `0x100E68` | send an A+D packet via GIF DMA (waits for idle first) |
| `0x10E798` | D-cache write-back by range |
| `0x133270` | graphics init `(w, h, …, mode flags)`; stores w/h at `0x174850`/`0x174854` |
| `0x142078` | video-mode selector; table at `0x182690` (entries 0–5) |
| `0x142318` | buffer swap (calls `PutDispEnv`, then kicks the env packet) |
| `0x1441C8` | DMA kick of a render context's packet |

Exact patch bytes are in [PATCH_SPEC.md](PATCH_SPEC.md).
