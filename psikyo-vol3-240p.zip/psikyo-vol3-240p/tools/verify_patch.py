#!/usr/bin/env python3
"""
Verify that an ISO is exactly the original image plus the down2 patch.
Usage: python3 tools/verify_patch.py <original.iso> <patched.iso>
Checks: (1) every patched site/blob in <patched.iso> holds the expected bytes,
        (2) every byte outside those regions is identical to <original.iso>.
Also prints SHA-256 of both files. Exit status 0 = OK.
"""
import sys, os, hashlib
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
import psikyo_vol3_240p as P

def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for c in iter(lambda: f.read(1 << 20), b''): h.update(c)
    return h.hexdigest()

def main():
    if len(sys.argv) != 3: sys.exit(__doc__)
    orig, patched = sys.argv[1:]
    if os.path.getsize(orig) != os.path.getsize(patched): sys.exit("FAIL: sizes differ")
    sites, blobs = P.build('down2')
    regions = []     # (offset, expected bytes)
    for rt, off, old, new, nm in sites:
        regions.append((off if off is not None else P.MAIN(rt), bytes.fromhex(new)))
    for data, rt in blobs: regions.append((P.MAIN(rt), data))
    regions.sort()
    ok = True
    with open(patched, 'rb') as f:
        for off, exp in regions:
            f.seek(off)
            if f.read(len(exp)) != exp: print(f"FAIL: unexpected bytes at {off:#x}"); ok = False
    # everything else must equal the original
    CH = 1 << 20
    with open(orig, 'rb') as a, open(patched, 'rb') as b:
        pos = 0
        while True:
            x, y = a.read(CH), b.read(CH)
            if not x: break
            if x != y:
                for i in range(len(x)):
                    if x[i] != y[i] and not any(o <= pos + i < o + len(e) for o, e in regions):
                        print(f"FAIL: stray difference at {pos+i:#x}"); ok = False; break
            pos += len(x)
    print("original :", sha256(orig)); print("patched  :", sha256(patched))
    print("RESULT   :", "OK - exactly original + down2 patch" if ok else "MISMATCH")
    sys.exit(0 if ok else 1)
if __name__ == '__main__': main()
